package com.example.team_management_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
